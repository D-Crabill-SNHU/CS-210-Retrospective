/*
 * ProjectOneClock.cpp
 *
 *  Date: 7/16/2026
 *  Author: Drew Crabill
 */

#include <iostream>
#include <vector>
using namespace std;


//Displays both clocks
void clockDisplay(vector<int> clock) {
	cout << "**************************   **************************" << endl;
	cout << "*     12-Hour Clock      *   *     24-Hour Clock      *" << endl;

	int hour = clock.at(0);
	int minute = clock.at(1);
	int second = clock.at(2);

	//Start of 12-Hour Clock time
	cout << "*     ";
	if ((hour >= 1 && hour <= 9) || (hour >= 13 && hour <= 21)) {
		cout << "0";
	}
	if (hour > 12) {
		cout << (hour - 12);
	}
	else {
		cout << hour;
	}
	cout << ":";

	if (minute < 10) {
		cout << "0";
	}
	cout << minute << ":";

	if (second < 10) {
		cout << "0";
	}
	cout << second;

	if (hour > 11 && hour < 24) {
		cout << " P M ";
	}
	else {
		cout << " A M ";
	}
	cout << "      *";
	//End of 12-Hour Clock time

	//Start of 24-Hour Clock time
	cout << "   *       ";
	if (hour < 10) {
		cout << "0";
	}
	cout << hour << ":";

	if (minute < 10) {
		cout << "0";
	}
	cout << minute << ":";

	if (second < 10) {
		cout << "0";
	}
	cout << second;
	
	cout << "        *" << endl;
	//End of 24-Hour Clock time




	cout << "**************************   **************************" << endl;
}

//Clock functionality
void clockWork(vector<int>& clock, int command) {
	//Increments whatever needs to be changed, if anything
	switch (command) {
	case 1:
		clock.at(0)++;
		break;
	case 2:
		clock.at(1)++;
		break;
	case 3:
		clock.at(2)++;
		break;
	default:
		//Nothing changes
		break;
	}

	//Updates clock values
	
	//Updates seconds
	if (clock.at(2) > 59) {
		clock.at(2) -= 60;
		clock.at(1)++;
	}

	//Updates minutes
	if (clock.at(1) > 59) {
		clock.at(1) -= 60;
		clock.at(0)++;
	}

	//Updates hours
	if (clock.at(0) > 24) {
		clock.at(0) -= 24;
	}
}

//Menu
void menu() {
	cout << "**************************" << endl;
	cout << "* 1 - Add One Hour       *" << endl;
	cout << "* 2 - Add One Minute     *" << endl;
	cout << "* 3 - Add One Second     *" << endl;
	cout << "* 4 - Exit Program       *" << endl;
	cout << "**************************" << endl << endl;
}

//Handles user interaction and input
bool inputControl(bool initial, vector<int>& clock) {
	//Initial input to set the clock
	if (initial) {
		while (true) {
			cout << "Please enter the hour (in 24-Hour Clock time) (1 - 24):";
			cin >> clock.at(0);
			cout << endl;
			if (clock.at(0) > 0 && clock.at(0) < 25) {
				break;
			}
		}

		while (true) {
			cout << "Please enter the minute (0 - 59):";
			cin >> clock.at(1);
			cout << endl;
			if (clock.at(1) >= 0 && clock.at(1) < 60) {
				break;
			}
		}

		while (true) {
			cout << "Please enter the second (0 - 59):";
			cin >> clock.at(2);
			cout << endl;
			if (clock.at(2) >= 0 && clock.at(2) < 60) {
				break;
			}
		}

		cout << "Time successfully entered." << endl << endl << endl;
		return true;
	}
	//Handles increments of time
	else {
		char response;

		while (true) {
			cout << "Would you like to add an hour? (Y or N):";
			cin >> response;
			cout << endl;
			if (response == 'Y' || response == 'y') {
				clockWork(clock, 1);
				clockDisplay(clock);
				return true;
			}
			else if (response == 'N' || response == 'n') {
				break;
			}
		}

		while (true) {
			cout << "Would you like to add a minute? (Y or N):";
			cin >> response;
			cout << endl;
			if (response == 'Y' || response == 'y') {
				clockWork(clock, 2);
				clockDisplay(clock);
				return true;
			}
			else if (response == 'N' || response == 'n') {
				break;
			}
		}

		while (true) {
			cout << "Would you like to add a second? (Y or N):";
			cin >> response;
			cout << endl;
			if (response == 'Y' || response == 'y') {
				clockWork(clock, 3);
				clockDisplay(clock);
				return true;
			}
			else if (response == 'N' || response == 'n') {
				break;
			}
		}

		return false;
	}
	
}


void main() {
	//Creates vector for the clock's values and uses a function to fill it
	vector<int> clock(3);
	inputControl(true, clock);

	bool run = true;
	//Loop for user interaction
	while (run) {
		menu();
		bool proceed = inputControl(false, clock);
		//If no increment was used, this block activates to confirm exit
		if (!proceed) {
			while (true) {
				char response;
				cout << "Would you like to exit? (Y or N):";
				cin >> response;
				cout << endl;
				if (response == 'Y' || response == 'y') {
					run = false;
					break;
				}
				else if (response == 'N' || response == 'n') {
					break;
				}
			}
		}
	}

}